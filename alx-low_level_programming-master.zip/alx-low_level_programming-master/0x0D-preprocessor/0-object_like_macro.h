#ifndef _OBJECT_LIKE_MACRO_
#define _OBJECT_LIKE_MACRO_

#define SIZE 1024

#endif
