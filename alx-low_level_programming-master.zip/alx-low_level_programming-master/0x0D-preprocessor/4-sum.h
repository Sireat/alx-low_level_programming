#ifndef _SUM_LIKE_MACRO_
#define _SUM_LIKE_MACRO_

#define SUM(x, y) ((x) + (y))

#endif
