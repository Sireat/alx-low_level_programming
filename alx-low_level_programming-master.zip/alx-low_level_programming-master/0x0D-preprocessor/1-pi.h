#ifndef _PI_
#define _PI_

#define PI 3.14159265359

#endif
