#include "main.h"

/**
 * reset_to_98 - takes a pointer to a parameter and updates its value.
 * @n: input integer.
 * Return: no return.
 */
void reset_to_98(int *n)
{
	*n = 98;
}
