C - Malloc Project
