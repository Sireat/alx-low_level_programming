#include "main.h"

/**
 * mul - multiplies two integers
 * @a: int to be multiplied to b
 * @b: int to be multiplied to a
 * Return: the result of the operation
 */
int mul(int a, int b)
{
	int c;

	c = a * b;

	return (c);
}
