C - Static libraries
