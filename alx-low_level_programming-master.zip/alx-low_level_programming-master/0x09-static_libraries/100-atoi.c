#include "main.h"
/**
 *_atoi - allow convert a string of numbers into int
 *
 *@s: input pointer
 *Return: int
 */

int _atoi(char *s)
{
	(void)s;
	return (0);
}
