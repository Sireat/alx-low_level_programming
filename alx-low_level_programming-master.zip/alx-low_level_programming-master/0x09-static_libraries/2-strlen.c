#include "main.h"
#include <stdio.h>

/**
 *_strlen - the string´s lenght
 *
 *@s: input char
 *Return: lenght of a string
 */

int _strlen(char *s)

{
	int i;

	for (i = 0; s[i] != '\0'; i++)
	{
	}
		return (i);
}
